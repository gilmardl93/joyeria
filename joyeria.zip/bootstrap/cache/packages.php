<?php return array (
  'rap2hpoutre/laravel-log-viewer' => 
  array (
    'providers' => 
    array (
      0 => 'Rap2hpoutre\\LaravelLogViewer\\LaravelLogViewerServiceProvider',
    ),
  ),
  'barryvdh/laravel-debugbar' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Debugbar\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Debugbar' => 'Barryvdh\\Debugbar\\Facade',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'styde/html' => 
  array (
    'providers' => 
    array (
      0 => 'Styde\\Html\\HtmlServiceProvider',
    ),
    'aliases' => 
    array (
      'Field' => 'Styde\\Html\\Facades\\Field',
      'Alert' => 'Styde\\Html\\Facades\\Alert',
      'Menu' => 'Styde\\Html\\Facades\\Menu',
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
    ),
    'dont-discover' => 
    array (
      0 => 'laravelcollective/html',
    ),
  ),
);