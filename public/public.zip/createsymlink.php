<?php

symlink('/home/pson8596/public_html/joyeria/storage/app/public','/home/pson8596/public_html/joyeria/public/storage');
